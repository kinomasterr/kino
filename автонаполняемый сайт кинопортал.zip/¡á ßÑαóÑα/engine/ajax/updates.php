<?php
echo <<<HTML
<div class="ui-state-error ui-corner-all" style="padding:10px;"><b>Внимание!</b>
<br />Во избежании проблем, в целях безопасности, проверка обновлений отключена!
</div>
HTML;
?>