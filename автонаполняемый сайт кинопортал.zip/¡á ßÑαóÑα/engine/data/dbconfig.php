<?PHP

define ("DBHOST", "Изменить или обично localhost");

define ("DBNAME", "имя базы");

define ("DBUSER", "имя пользователя");

define ("DBPASS", "пароль");

define ("PREFIX", "dle");

define ("USERPREFIX", "dle");

define ("COLLATE", "utf8mb4");

define('SECURE_AUTH_KEY', 'VC7g~pvxB`o}5|#lJ0>nSJU;x3;VAc]jS=ck;tXOYxX%EJ?)+%.l^RNfgtpiR*&L');

$db = new db;

?>